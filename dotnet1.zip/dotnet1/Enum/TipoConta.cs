namespace DIO.Bank
{
    public enum TipoConta
    {
        PessoaFisica = 1,
        PessoaJuridica = 2
    }
}